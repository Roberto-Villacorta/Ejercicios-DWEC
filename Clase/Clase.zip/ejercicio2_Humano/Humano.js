"use strict";

class Humano {
    static LETRAS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZáéíóúüÁÉÍÓÚÜñÑçÇ";
    static DIGITOS = "0123456789";

    #nombre;
    #peso;
    #edad;

    constructor(nombre, peso, edad) {
        this.nombre = nombre;
        this.peso = peso;
        this.edad = edad;
    }

    static esDigitos(texto) {
        if (typeof texto !== "string" || texto.length === 0) return false;
        for (let i = 0; i < texto.length; i++) {
            if (!Humano.DIGITOS.includes(texto[i])) return false;
        }
        return true;
    }

    static validarNombre(valor) {
        valor = String(valor);
        if (valor.length === 0 || valor.length > 20) {
            return "Nombre: debe tener entre 1 y 20 caracteres.";
        }
        for (let i = 0; i < valor.length; i++) {
            if (!Humano.LETRAS.includes(valor[i])) {
                return "Nombre: solo se permiten caracteres alfabéticos (incluidas ñ, ç y vocales acentuadas).";
            }
        }
        return "";
    }

    static validarPeso(valor) {
        const str = String(valor);
        return (str.length >= 1 && str.length <= 3 && Humano.esDigitos(str))
            ? "" : "Peso: solo caracteres numéricos del 0 al 9 (máximo 3 cifras).";
    }

    static validarEdad(valor) {
        const str = String(valor);
        return (str.length >= 1 && str.length <= 3 && Humano.esDigitos(str))
            ? "" : "Edad: solo caracteres numéricos del 0 al 9 (máximo 3 cifras).";
    }

    static comprobar(error) {
        if (error) throw new Error(error);
    }
    get nombre() { return this.#nombre; }
    set nombre(v) { Humano.comprobar(Humano.validarNombre(v)); this.#nombre = String(v); }

    get peso() { return this.#peso; }
    set peso(v) { Humano.comprobar(Humano.validarPeso(v)); this.#peso = Number(v); }

    get edad() { return this.#edad; }
    set edad(v) { Humano.comprobar(Humano.validarEdad(v)); this.#edad = Number(v); }

    comer() {
        this.peso = this.peso + 1;
    }

    correr() {
        if (this.peso > 0) this.peso = this.peso - 1;
    }
    categoria() {
        const e = this.edad;
        if (e < 10 || e > 79) return "Fuera de categoría";
        if (e <= 11) return "Benjamín";
        if (e <= 13) return "Alevín";
        if (e <= 15) return "Infantil";
        if (e <= 17) return "Cadete";
        if (e <= 19) return "Junior";
        if (e <= 29) return "Senior 20";
        if (e <= 39) return "Senior 30";
        if (e <= 49) return "Senior 40";
        if (e <= 59) return "Senior 50";
        if (e <= 69) return "Senior 60";
        return "Senior 70";
    }
    static listado(array) {
        Humano.#abrirVentana("Listado", array, "Cerrar");
    }

    static muestraUnaPersona(humano) {
        Humano.#abrirVentana("Muestra una persona", [humano], "Cerrar");
    }

    static #esc(texto) {
        return String(texto)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#39;");
    }

    static #abrirVentana(titulo, lista, textoBoton) {
        const w = window.open("", "_blank", "width=480,height=360,scrollbars=yes,resizable=yes");
        if (!w) { alert("El navegador ha bloqueado la ventana emergente. Permítela e inténtalo de nuevo."); return; }
        w.document.open();
        w.document.write(Humano.#html(titulo, lista, textoBoton));
        w.document.close();
    }

    static #html(titulo, lista, textoBoton, cabecera = "") {
        const filas = lista.map(h => `
            <tr><td>${Humano.#esc(h.nombre)}</td><td>${h.peso}</td><td>${h.edad}</td><td>${Humano.#esc(h.categoria())}</td></tr>`).join("");
        return `<!DOCTYPE html>
<html lang="es"><head><meta charset="utf-8"><title>${Humano.#esc(titulo)}</title>
<style>
    body { font-family: Times New Roman, serif; text-align: center; margin: 12px; }
    table { margin: 0 auto; border: 3px double #444; border-collapse: separate; border-spacing: 2px; }
    th, td { border: 1px solid #444; padding: 2px 5px; text-align: left; }
    button { margin-top: 14px; }
</style></head><body>
${cabecera}
<table>
    <tr><th>Nombre</th><th>Peso</th><th>Edad</th><th>Categoria</th></tr>
    ${filas}
</table>
<button onclick="window.close()">${textoBoton}</button>
</body></html>`;
    }

    /** Solo para uso del listado externo (otroListado), que NO forma parte de la clase. */
    static htmlTabla(titulo, lista, textoBoton, cabecera) {
        return Humano.#html(titulo, lista, textoBoton, cabecera);
    }
}
